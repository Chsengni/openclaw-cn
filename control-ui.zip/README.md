# openclaw-cn
前端汉化包control-ui

替换openclaw\dist\control-ui即可汉化
